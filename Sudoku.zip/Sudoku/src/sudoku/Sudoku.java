/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sudoku;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author M
 */
public class Sudoku extends JPanel implements Runnable,MouseListener,MouseMotionListener,KeyListener{

    public JPanel panel=new JPanel();
    public JFrame frame=new JFrame("Sudoku");
    public Thread thread;
    
    public boolean mouse_clicked=false;
    public boolean sudoku_complete=false;
    public int sec=0,min=0;
    public long start,now;
    
    public int cx=0,cy=0;
    
    public int old_cx=0,old_cy=0;
    public int old_mouse_x=0;
    public int old_mouse_y=0;
    
    public int x,y;
    public int r,l=0;
    
    public static int[][] table=new int[8][8];
    public static int[][] table_unMovable=new int[8][8];
    public static int[][] complete=new int[8][8];
    
    Sudoku()
    {
        start=System.currentTimeMillis();
        
        Font font=new Font("Arial", Font.PLAIN, 25);
        this.addMouseListener(this);
        this.addMouseMotionListener(this);
        
        this.addKeyListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        
        table=new int[][]{{0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0}
        };
        
        complete=new int[][]{{0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0}
        };
        
        table_unMovable=new int[][]{{1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1}
        };
        
        generate_board();
        remove_some_fields();
    }
    
    public void remove_some_fields()
    {
        Random rnd=new Random();
        
        for(int i=0;i<40;i++){
            int rx=rnd.nextInt(8);
            int ry=rnd.nextInt(9);
            table[ry][rx]=0;
            table_unMovable[ry][rx]=0;
        }
    }
    
    public void check_board()
    {
        boolean isCorrect=true;
        for(int y=0;y<9;y++)
        {
        for(int x=0;x<9;x++)
        {
            if(table[y][x]!=complete[y][x]){isCorrect=false;};
        }
        }
        sudoku_complete=isCorrect;
        System.out.println("isCorrect "+isCorrect);
    }
    
    public void check_board_2()
    {
        int sum=0;
        boolean isCorrect=true;
        for(int y=0;y<9;y++)
        {
            sum=0;
        for(int x=0;x<9;x++)
        {
            
            sum=sum+table[y][x];
        }
            if(sum!=45){isCorrect=false;};
        }
        
        for(int x=0;x<9;x++)
        {
            sum=0;
        for(int y=0;y<9;y++)
        {
            
            sum=sum+table[y][x];
        }
            if(sum!=45){isCorrect=false;};
        }
        
        sudoku_complete=isCorrect;
        System.out.println("isCorrect "+isCorrect);
    }
    
    public static void main(String[] args) {
        Sudoku s=new Sudoku();
        s.panel = s;
        s.frame = new JFrame("Mateusz Pawlowski. Sudoku 2024.");
        s.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        s.frame.getContentPane().add(s.panel);
        s.panel.setSize(300, 300);
        s.frame.setLocation(500, 300);
        s.frame.pack();
        s.frame.show();
        s.thread=new Thread(s);
        s.thread.start();
    }

    @Override
    public void run() {
        
        while(true)
        {
            try{
            cx=(int)(this.old_mouse_x)/50;
            cy=(int)(this.old_mouse_y)/50;       

            now=System.currentTimeMillis();
            long delta=now-start;
            int inSeconds=(int)delta/1000;
            
            if(inSeconds<=60) sec=inSeconds;else
            {
            min=(int)inSeconds/60;sec=inSeconds%60;
            }
            
            //System.out.println(inSeconds);
            this.repaint();
            Thread.sleep(25);
            }catch(Exception exc){};
        }
    }
    
    public void paintComponent(Graphics g){
    	super.paintComponent(g);
        g.setColor(Color.white);
        g.setColor(new Color(255,255,255));
        g.fillRect(0, 0, 640, 520);
        
        
        
        
        g.setFont(new Font("Dialog", Font.ITALIC, 40));
        
        for(int y=0;y<9;y++)
        {
        for(int x=0;x<9;x++)
        {
            g.setColor(new Color(190,190,190));
            g.drawRect(x*50, y*50, 50, 50);
            
            g.setColor(new Color(0,0,0));
            
            if(table[y][x]==0) g.drawString(" ", 16+x*50, y*50+50-7);
            if(table[y][x]==1) g.drawString("1", 16+x*50, y*50+50-7);
            if(table[y][x]==2) g.drawString("2", 16+x*50, y*50+50-7);
            if(table[y][x]==3) g.drawString("3", 16+x*50, y*50+50-7);
            if(table[y][x]==4) g.drawString("4", 16+x*50, y*50+50-7);
            if(table[y][x]==5) g.drawString("5", 16+x*50, y*50+50-7);
            if(table[y][x]==6) g.drawString("6", 16+x*50, y*50+50-7);
            if(table[y][x]==7) g.drawString("7", 16+x*50, y*50+50-7);
            if(table[y][x]==8) g.drawString("8", 16+x*50, y*50+50-7);
            if(table[y][x]==9) g.drawString("9", 16+x*50, y*50+50-7);
            
        }
        }
        
        if(sudoku_complete) g.drawString("Sudoku solved.", 100, 500);
        
        g.drawString("Start new.", 460, 40);
        g.drawRect(460, 0, 175, 50);
        g.drawString("Time", 500, 100);
        g.drawString(""+min+":"+sec, 510, 150);
        
        g.setColor(new Color(0,0,0));
        
        if(cx<9&&cy<9){
            g.drawRect(cx*50, cy*50, 50, 50);
        }
        
        for(int y=0;y<3;y++)
        {
        for(int x=0;x<3;x++)
        {
            g.drawRect(x*150, y*150, 150, 150);
        }
        }
    }
    
public boolean sprawdz_wiersz() 
{
	for (int a = 0; a < 9; a++) 
	{
		if (table[y][a] == r) { return true; }
	}
	return false;
}

public boolean sprawdz_kolumne()
{
	for (int a = 0; a < 9; a++)
	{
		if (table[a][x] == r) { return true; }
	}
	return false;
}

public boolean k1() 
{
	if (table[0][0] == r) { return true; }
	if (table[0][1] == r) { return true; }
	if (table[0][2] == r) { return true; }
	
	if (table[1][0] == r) { return true; }
	if (table[1][1] == r) { return true; }
	if (table[1][2] == r) { return true; }
	
	if (table[2][0] == r) { return true; }
	if (table[2][1] == r) { return true; }
	if (table[2][2] == r) { return true; }
	return false;
}

public boolean k2()
{
	if (table[0][3] == r) { return true; }
	if (table[0][4] == r) { return true; }
	if (table[0][5] == r) { return true; }

	if (table[1][3] == r) { return true; }
	if (table[1][4] == r) { return true; }
	if (table[1][5] == r) { return true; }

	if (table[2][3] == r) { return true; }
	if (table[2][4] == r) { return true; }
	if (table[2][5] == r) { return true; }
	return false;
}

public boolean k3()
{
	if (table[0][6] == r) { return true; }
	if (table[0][7] == r) { return true; }
	if (table[0][8] == r) { return true; }

	if (table[1][6] == r) { return true; }
	if (table[1][7] == r) { return true; }
	if (table[1][8] == r) { return true; }

	if (table[2][6] == r) { return true; }
	if (table[2][7] == r) { return true; }
	if (table[2][8] == r) { return true; }
	return false;
}

public boolean k4()
{
	if (table[3][0] == r) { return true; }
	if (table[3][1] == r) { return true; }
	if (table[3][2] == r) { return true; }

	if (table[4][0] == r) { return true; }
	if (table[4][1] == r) { return true; }
	if (table[4][2] == r) { return true; }

	if (table[5][0] == r) { return true; }
	if (table[5][1] == r) { return true; }
	if (table[5][2] == r) { return true; }
	return false;
}

public boolean k5()
{
	if (table[3][3] == r) { return true; }
	if (table[3][4] == r) { return true; }
	if (table[3][5] == r) { return true; }

	if (table[4][3] == r) { return true; }
	if (table[4][4] == r) { return true; }
	if (table[4][5] == r) { return true; }

	if (table[5][3] == r) { return true; }
	if (table[5][4] == r) { return true; }
	if (table[5][5] == r) { return true; }
	return false;
}

public boolean k6()
{
	if (table[3][6] == r) { return true; }
	if (table[3][7] == r) { return true; }
	if (table[3][8] == r) { return true; }

	if (table[4][6] == r) { return true; }
	if (table[4][7] == r) { return true; }
	if (table[4][8] == r) { return true; }

	if (table[5][6] == r) { return true; }
	if (table[5][7] == r) { return true; }
	if (table[5][8] == r) { return true; }
	return false;
}

public boolean k7()
{
	if (table[6][0] == r) { return true; }
	if (table[6][1] == r) { return true; }
	if (table[6][2] == r) { return true; }

	if (table[7][0] == r) { return true; }
	if (table[7][1] == r) { return true; }
	if (table[7][2] == r) { return true; }

	if (table[8][0] == r) { return true; }
	if (table[8][1] == r) { return true; }
	if (table[8][2] == r) { return true; }
	return false;
}

public boolean k8()
{
	if (table[6][3] == r) { return true; }
	if (table[6][4] == r) { return true; }
	if (table[6][5] == r) { return true; }

	if (table[7][3] == r) { return true; }
	if (table[7][4] == r) { return true; }
	if (table[7][5] == r) { return true; }

	if (table[8][3] == r) { return true; }
	if (table[8][4] == r) { return true; }
	if (table[8][5] == r) { return true; }
	return false;
}

public boolean k9()
{
	if (table[6][6] == r) { return true; }
	if (table[6][7] == r) { return true; }
	if (table[6][8] == r) { return true; }

	if (table[7][6] == r) { return true; }
	if (table[7][7] == r) { return true; }
	if (table[7][8] == r) { return true; }

	if (table[8][6] == r) { return true; }
	if (table[8][7] == r) { return true; }
	if (table[8][8] == r) { return true; }
	return false;
}

public boolean sprawdz_kwadrat() 
{
	boolean sprawdz = false;

	if (x >= 0 && x < 3 && y>=0 && y < 3) { sprawdz = k1(); }
	if (x >= 3 && x < 6 && y >= 0 && y < 3) { sprawdz = k2(); }
	if (x >= 6 && x < 9 && y >= 0 && y < 3) { sprawdz = k3(); }
	
	if (x >= 0 && x < 3 && y >= 3 && y < 6) { sprawdz = k4(); }
	if (x >= 3 && x < 6 && y >= 3 && y < 6) { sprawdz = k5(); }
	if (x >= 6 && x < 9 && y >= 3 && y < 6) { sprawdz = k6(); }

	if (x >= 0 && x < 3 && y >= 6 && y < 9) { sprawdz = k7(); }
	if (x >= 3 && x < 6 && y >= 6 && y < 9) { sprawdz = k8(); }
	if (x >= 6 && x < 9 && y >= 6 && y < 9) { sprawdz = k9(); }

	return sprawdz;
}

public boolean zeruj() 
{
	for (y = 0; y < 9; y++)
	{
		for (x = 0; x < 9; x++)
		{
			table[y][x] = 0;
		}
	}
	x = 0; y = 0;
	return false;
}

public void generate_board()
{

    
	Random rnd=new Random();
        r=rnd.nextInt(8)+1;
	for (y = 0; y < 9; y++)
	{

		for (x = 0; x < 9; x++)
		{
			r=rnd.nextInt(8)+1;

			l = 0;

			while (sprawdz_wiersz() == true || sprawdz_kolumne() == true || sprawdz_kwadrat() == true)
			{
				l++;
				r=rnd.nextInt(9)+1;
				if (l == 30000) { zeruj(); }
			}
				
				table[y][x] = r;
                                complete[y][x] = r;
                                
				boolean t = true;
				if (x == 8 && y == 8) 
				{
					return;
					
					//zeruj();
				}
		}
	}
}

    public Dimension getPreferredSize(){
        return new Dimension(640, 520);
    }
    
    @Override
    public void mouseClicked(MouseEvent me) {
        if(this.old_mouse_x>460&&this.old_mouse_x<460+175)
        {
        if(this.old_mouse_y>0&&this.old_mouse_y<50)
        {
            System.out.println("new");
            reload_game();
        }
        }
            
    }

    public void reload_game()
    {
        start=System.currentTimeMillis();
        sudoku_complete=false;
        sec=0;min=0;
        start=System.currentTimeMillis();
        now=System.currentTimeMillis();
        
        table=new int[][]{{0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0}
        };
        
        complete=new int[][]{{0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0},
                          {0,0,0,0,0,0,0,0,0}
        };
        
        table_unMovable=new int[][]{{1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1},
                          {1,1,1,1,1,1,1,1,1}
        };
        
        generate_board();
        remove_some_fields();
    };
    
    @Override
    public void mousePressed(MouseEvent me) {
        mouse_clicked=true; 
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        mouse_clicked=false; 
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        
    }

    @Override
    public void mouseExited(MouseEvent me) {
        
    }

    @Override
    public void mouseDragged(MouseEvent me) {
        
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        this.old_mouse_x=e.getX();
        this.old_mouse_y=e.getY();  
    }

    @Override
    public void keyTyped(KeyEvent ke) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(cx<9&&cy<9){
            if(table_unMovable[cy][cx]!=1){
                if(e.getKeyCode()==49){System.out.println("1");table[cy][cx]=1;}
                if(e.getKeyCode()==50){System.out.println("2");table[cy][cx]=2;}
                if(e.getKeyCode()==51){System.out.println("3");table[cy][cx]=3;}
                if(e.getKeyCode()==52){System.out.println("4");table[cy][cx]=4;}
                if(e.getKeyCode()==53){System.out.println("5");table[cy][cx]=5;}
                if(e.getKeyCode()==54){System.out.println("6");table[cy][cx]=6;}
                if(e.getKeyCode()==55){System.out.println("7");table[cy][cx]=7;}
                if(e.getKeyCode()==56){System.out.println("8");table[cy][cx]=8;}
                if(e.getKeyCode()==57){System.out.println("9");table[cy][cx]=9;}
                if(e.getKeyCode()==127){System.out.println("Del");table[cy][cx]=0;}
                check_board_2();
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        
    }
    
}
